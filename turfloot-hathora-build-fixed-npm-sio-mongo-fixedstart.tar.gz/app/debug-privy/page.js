export const dynamic = 'force-dynamic'

export default function DebugPrivy() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Debug Privy</h1>
      <p className="text-gray-600">Privy debug functionality.</p>
    </div>
  )
}